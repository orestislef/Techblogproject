# Techblogproject

Techblog.gr website Testing retrofit2 implementation to populate threds into recyclerView
